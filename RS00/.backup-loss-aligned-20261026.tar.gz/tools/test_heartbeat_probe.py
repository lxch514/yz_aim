"""Offline polling-window diagnostics tests. All CAN sockets are fake."""
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import rs00_test as m
from selftest_rs00 import motor


class PollWindowPositionVelocity(unittest.TestCase):
    def prepare(self, clock):
        a = motor()
        logs = []
        a.log = logs.append
        a.report_ms = 55
        a._heartbeat_probe_last_mono = clock[0]
        a.enable_heartbeat_probe(50)
        return a, logs

    def test_at_50ms_not_motor_70ms_or_1point5_heartbeat_period(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            clock[0] = 10.049
            a.check_heartbeat_probe()
            self.assertEqual(len(a._heartbeat_probe_queue), 0)
            clock[0] = 10.050001
            a.check_heartbeat_probe()
            self.assertEqual(len(a._heartbeat_probe_queue), 1)
            self.assertEqual(a.heartbeat_probe_window_ms, 50.0)
            self.assertLess(clock[0] - 10, .070)
            self.assertLess(clock[0] - 10, 1.5 * a.report_ms / 1000)

    def test_two_reads_start_immediately_at_window_end(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, logs = self.prepare(clock)
            clock[0] = 10.050001
            calls = []
            def read(index, budget):
                calls.append((index, budget, clock[0]))
                return 1.25 if index == m.IDX_MECH_POS else -.75
            with patch.object(a, 'read_param', side_effect=read):
                a.run_heartbeat_checks()
        self.assertEqual([r[0] for r in calls], [0x7019, 0x701B])
        self.assertEqual([r[1] for r in calls], [50, 50])
        self.assertEqual(calls[0][2], 10.050001)
        r = a.stats['heartbeat_position_probes'][0]
        self.assertEqual(r['position_rad'], 1.25)
        self.assertEqual(r['velocity_rad_s'], -.75)
        self.assertTrue(all(v['before_heartbeat_recovery'] for v in r['readings'].values()))
        self.assertTrue(any('0x701B' in l and '-0.750000rad/s' in l for l in logs))

    def test_heartbeat_in_window_suppresses_probe(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            clock[0] = 10.045
            a._on_frame(m.build_id(m.M_REPORT, 127, 253), bytes(8))
            clock[0] = 10.050001
            a.check_heartbeat_probe()
        self.assertEqual(a.stats['heartbeat_position_probes'], [])

    def test_consecutive_empty_windows_each_get_a_pair(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            with patch.object(a, 'read_param', return_value=2.0) as read:
                for t in [10.050001, 10.100001, 10.150001]:
                    clock[0] = t
                    a.run_heartbeat_checks()
                self.assertEqual(read.call_count, 6)
        self.assertEqual([r['window_number'] for r in a.stats['heartbeat_position_probes']], [1, 2, 3])

    def test_boundary_heartbeat_belongs_to_next_window(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            clock[0] = a._heartbeat_probe_window_deadline
            a._heartbeat_probe_on_report(70, clock[0])
            self.assertEqual(len(a.stats['heartbeat_position_probes']), 1)
            clock[0] = 10.100001
            a.check_heartbeat_probe()
            self.assertEqual(len(a.stats['heartbeat_position_probes']), 1)

    def test_existing_request_is_never_overwritten(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            clock[0] = 10.050001
            a.pending = (m.M_READ, 0x701C)
            with patch.object(a, 'read_param', side_effect=AssertionError('nested read')):
                self.assertFalse(a.run_heartbeat_checks())
                self.assertEqual(a.pending, (m.M_READ, 0x701C))
            clock[0] = 10.055
            a.pending = None
            with patch.object(a, 'read_param', return_value=0):
                self.assertTrue(a.run_heartbeat_checks())
        self.assertAlmostEqual(a.stats['heartbeat_position_probes'][0]['request_delay_ms'], 4.999, places=3)

    def test_position_timeout_does_not_skip_velocity(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            clock[0] = 10.050001
            with patch.object(a, 'read_param', side_effect=[None, -.5]) as read:
                a.run_heartbeat_checks()
                self.assertEqual(read.call_count, 2)
        r = a.stats['heartbeat_position_probes'][0]
        self.assertEqual(r['status'], 'partial')
        self.assertEqual(r['readings']['position']['status'], 'timeout')
        self.assertEqual(r['readings']['velocity']['status'], 'success')

    def test_each_read_has_its_own_status_and_recovery_time(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            clock[0] = 10.050001
            def read(index, budget):
                if index == m.IDX_MECH_POS:
                    a.last_status = 1
                    a._heartbeat_probe_on_report(60, 10.060)
                    return None
                a.last_status = 0
                return 2.5
            with patch.object(a, 'read_param', side_effect=read):
                a.run_heartbeat_checks()
        reads = a.stats['heartbeat_position_probes'][0]['readings']
        self.assertEqual(reads['position']['status'], 'rejected')
        self.assertEqual(reads['position']['status_code'], 1)
        self.assertTrue(reads['position']['before_heartbeat_recovery'])
        self.assertFalse(reads['velocity']['before_heartbeat_recovery'])

    def test_send_failure_and_invalid_float_are_preserved(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            clock[0] = 10.050001
            a.last_send_ok = False
            with patch.object(a, 'read_param', side_effect=[None, float('nan')]):
                a.run_heartbeat_checks()
        r = a.stats['heartbeat_position_probes'][0]
        self.assertEqual(r['readings']['position']['status'], 'send_failed')
        self.assertEqual(r['readings']['velocity']['status'], 'invalid_value')
        json.dumps(r, allow_nan=False)

    def test_drain_dispatches_at_50ms_without_waiting_for_motor_idle_window(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            def pump(wait):
                clock[0] += wait
            with patch.object(a, 'pump', side_effect=pump), patch.object(a, 'read_param', return_value=0) as read:
                a.drain(.050001)
            self.assertEqual(read.call_count, 2)
            self.assertAlmostEqual(a.stats['heartbeat_position_probes'][0]['request_delay_ms'], 0)

    def test_summary_and_shutdown_queue(self):
        clock = [10.0]
        with patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            a, _ = self.prepare(clock)
            clock[0] = 10.050001
            with patch.object(a, 'read_param', side_effect=[4.5, -.25]):
                a.run_heartbeat_checks()
            clock[0] = 10.100001
            a.check_heartbeat_probe()
            a.end_report_window()
        r = a.stats['heartbeat_position_probes']
        self.assertEqual(r[1]['status'], 'not_run_before_shutdown')
        self.assertFalse(a.heartbeat_probe_enabled)
        report = '\n'.join(m.heartbeat_position_probe_report(a.stats))
        self.assertIn('0x7019', report)
        self.assertIn('0x701B', report)
        self.assertIn('-0.250000', report)
        self.assertIn('收尾前未执行', report)
        self.assertEqual(len(a._heartbeat_probe_queue), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
